# Daniela Nascimento — site

## Como publicar no GitHub Pages

1. Entre no seu repositório do GitHub.
2. Clique em **Add file → Upload files**.
3. Arraste **a pasta inteira** deste projeto (ou os arquivos `index.html` e a pasta `assets`).
4. Clique em **Commit changes**.
5. Vá em **Settings → Pages**.
6. Em **Build and deployment**, selecione:
   - Source: **Deploy from a branch**
   - Branch: **main** e pasta **/(root)**
7. Salve e aguarde o GitHub gerar o endereço do site.

### Estrutura
- `index.html` — página completa.
- `assets/daniela-hero.png` — foto principal.

Não renomeie a pasta `assets`, nem o arquivo `daniela-hero.png`, sem alterar o `src` no HTML.
